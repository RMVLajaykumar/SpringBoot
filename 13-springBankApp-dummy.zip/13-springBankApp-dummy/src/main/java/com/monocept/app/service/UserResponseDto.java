package com.monocept.app.service;

import java.util.Set;

import com.monocept.app.dto.CustomerResponseDto;
import com.monocept.app.entity.Role;

import lombok.Data;
@Data
public class UserResponseDto {
	private Long id;

	private String email;
	private String password;
	private Set<Role> roles;
	private CustomerResponseDto customerResponseDto;
}

