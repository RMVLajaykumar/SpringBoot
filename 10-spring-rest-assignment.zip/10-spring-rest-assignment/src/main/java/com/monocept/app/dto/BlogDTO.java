package com.monocept.app.dto;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class BlogDTO {
    private int id;

    @NotBlank(message = "Title must not be blank. 'Please provide a title to make your blog more informative.'")
    private String title;

    @NotBlank(message = "Category must not be blank. 'Please provide a category for better organization.'")
    private String category;

    @NotBlank(message = "Data must not be blank. Please provide the required information.")
    @Size(min = 10, max = 200, message = "Data must be between 50 and 2000 characters.")
    private String data;

    @NotNull(message = "Published date must not be null. Please provide the publication date.")
    @FutureOrPresent(message = "Published date must be in the present or future. Please provide a valid date.")
    private LocalDateTime publishedDate = LocalDateTime.now();

    private boolean published;

    private List<CommentDTO> comments;

   
    public BlogDTO(int id, String title, String category, String data, LocalDateTime publishedDate, boolean published, List<CommentDTO> comments) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.data = data;
        this.publishedDate = publishedDate;
        this.published = published;
        this.comments = comments;
    }

    public BlogDTO() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public LocalDateTime getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(LocalDateTime publishedDate) {
        this.publishedDate = publishedDate;
    }

    public boolean isPublished() {
        return published;
    }

    public void setPublished(boolean published) {
        this.published = published;
    }

    public List<CommentDTO> getComments() {
        return comments;
    }

    public void setComments(List<CommentDTO> comments) {
        this.comments = comments;
    }
}
