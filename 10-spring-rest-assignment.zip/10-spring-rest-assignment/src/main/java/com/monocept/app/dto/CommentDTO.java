package com.monocept.app.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CommentDTO {
    private int id;

    @NotBlank(message = "Description must not be blank. Please provide a description to add more details.")
    @Size(min = 2, max = 50, message = "Description must be between 50 and 200 characters.")
    private String description;

    // No reference to BlogDTO to prevent nesting issues
    
    // Constructors, getters, and setters
    public CommentDTO(int id, String description) {
        this.id = id;
        this.description = description;
    }

    public CommentDTO() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "CommentDTO [id=" + id + ", description=" + description + "]";
    }
}
