package com.monocept.app.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.monocept.app.dto.AccountRequestDto;
import com.monocept.app.dto.AccountResponseDto;
import com.monocept.app.dto.BankRequestDto;
import com.monocept.app.dto.CustomerRequestDto;
import com.monocept.app.dto.CustomerResponseDto;
import com.monocept.app.dto.TransactionResponseDto;
import com.monocept.app.entity.Account;
import com.monocept.app.entity.Bank;
import com.monocept.app.entity.Customer;
import com.monocept.app.entity.Transaction;
import com.monocept.app.entity.TransactionType;
import com.monocept.app.exception.NoRecordFoundException;
import com.monocept.app.repository.AccountRepository;
import com.monocept.app.repository.BankRepository;
import com.monocept.app.repository.CustomerRepository;
import com.monocept.app.repository.TransactionRepository;

@Service
public class BankServiceImpl implements BankService{
	CustomerRepository customerRepository;
	
	AccountRepository accountRepository;
	BankRepository bankRepository;
	TransactionRepository transactionRepository;

	


	public BankServiceImpl(CustomerRepository customerRepository, AccountRepository accountRepository,
			BankRepository bankRepository, TransactionRepository transactionRepository) {
		super();
		this.customerRepository = customerRepository;
		this.accountRepository = accountRepository;
		this.bankRepository = bankRepository;
		this.transactionRepository = transactionRepository;
	}


	@Override
	public List<CustomerResponseDto> getAllCustomers() {
		
		return  convertCustomertoCustomerDto(customerRepository.findAll());
	}


	private List<CustomerResponseDto> convertCustomertoCustomerDto(List<Customer> all) {
		List<CustomerResponseDto> customers=new ArrayList<>();
		
		for(Customer i:all) {
			CustomerResponseDto customer=new CustomerResponseDto();
			customer.setCustomer_id(i.getCustomer_id());
			customer.setFirstName(i.getFirstName());
			customer.setLastName(i.getLastName());
			customer.setTotalBalance(i.getTotalBalance());		
			customer.setAccounts(convertAccounttoAccountResponseDto(i.getAccounts()));
			customers.add(customer);
		}
		return customers;
	}

  

	private List<AccountResponseDto> convertAccounttoAccountResponseDto(List<Account> accounts) {
	
	
		List<AccountResponseDto> accountResponseDto=new ArrayList<>();
		for(Account account:accounts) {
			
			accountResponseDto.add(	convertAccounttoAccountResponseDto(account));
			
		}
		return accountResponseDto;
	}


	private AccountResponseDto convertAccounttoAccountResponseDto(Account account) {
		
		AccountResponseDto accountResponseDto= new AccountResponseDto();
		accountResponseDto.setAccountNumber(account.getAccountNumber());
		accountResponseDto.setBalance(account.getBalance());
		return accountResponseDto;
	}


	@Override
	public CustomerResponseDto addCustomer(CustomerRequestDto customerrequestdto) {
		
		Customer customer=convertcustomerRequestDtoToCustomer(customerrequestdto);
		return convertCustomerTocustomerResponseDto(customerRepository.save(customer));
		
	}


	private CustomerResponseDto convertCustomerTocustomerResponseDto(Customer customer) {
		CustomerResponseDto customer1 =  new CustomerResponseDto();
		customer1.setCustomer_id(customer.getCustomer_id());
		customer1.setFirstName(customer.getFirstName());
		customer1.setLastName(customer.getLastName());
		customer1.setTotalBalance(customer.getTotalBalance());
		return customer1;
	}


	private Customer convertcustomerRequestDtoToCustomer(CustomerRequestDto customerrequestdto) {
		Customer customer =  new Customer();
		customer.setCustomer_id(customerrequestdto.getCustomer_id());
		customer.setFirstName(customerrequestdto.getFirstName());
		customer.setLastName(customerrequestdto.getLastName());
		customer.setTotalBalance(customerrequestdto.getTotalBalance());
		return customer;
	}


	@Override
	public String deleteCustomerById(long id) {
		
		
		Customer customer=customerRepository.findById(id).orElse(null);
		if(customer!=null) {
			customerRepository.deleteById(id);
			
		}
		else {
			return "cannot find id";
		}
		return "customer deleted Successfully";
		
	}


	@Override
	public CustomerResponseDto findCustomerByid(long id) {
		Customer customer = customerRepository.findById(id).orElse(null);
		 
		return convertCustomerTocustomerResponseDto(customer);
	}


	@Override
	public CustomerResponseDto addAccount(long cid,int bid) {
		
		 Account account = new Account();
		 Bank bank = bankRepository.findById(bid).orElse(null);
		
		 
		 if(bank != null) {
			 Customer customer = customerRepository.findById(cid).orElse(null);
			 
			 if(customer != null){
				 
				//return convertAccounttoAccountResponseDto(accountRepository.save(account));
				 account.setBalance(1000);
				 account.setBank(bank);
				 account.setCustomer(customer);
				 
				 customer.addbankAccount(account);
				 double total_salary=1000;
				 if(accountRepository.getTotalBalance(customer)!=0) {
					 total_salary+=accountRepository.getTotalBalance(customer);
				 }
				 customer.setTotalBalance(total_salary);
				 Customer save = customerRepository.save(customer);
				 return convertCustomerTocustomerResponseDto(save);
				 
			 }
		 }
		return null;
		
		 
	
	
	}


	private Account convertAcountResponseDtoToAccount(AccountRequestDto accountRequestDto) {
		Account account=new Account();
		account.setAccountNumber(accountRequestDto.getAccountNumber());
		account.setBalance(accountRequestDto.getBalance());
		account.setBank(convertBankDtotoBank(accountRequestDto.getBankrequestDto()));
		account.setCustomer(convertcustomerDtoToCustomer(accountRequestDto.getCustomerRequestDto()));
		return account;
		
	}


	


	private Customer convertcustomerDtoToCustomer(CustomerRequestDto customerRequestDto) {
	
		Customer customer = new Customer();
		customer.setCustomer_id(customerRequestDto.getCustomer_id());
		customer.setFirstName(customerRequestDto.getFirstName());
		customer.setLastName(customerRequestDto.getLastName());
		customer.setTotalBalance(customerRequestDto.getTotalBalance());
		return customer;
	}


	private Bank convertBankDtotoBank(BankRequestDto bank) {
		Bank bank1 = new Bank();
		bank1.setBank_id(bank.getBank_id());
		bank1.setAbbreviation(bank.getAbbreviation());
		bank1.setFullName(bank.getFullName());
		return bank1;
	}


	@Override
	public TransactionResponseDto doTransaction(long senderAccountno, long receiverAccountno, double amount) {
		
		
		Account senderAccount=accountRepository.findById(senderAccountno).orElse(null);
		Account receiverAccount=accountRepository.findById(receiverAccountno).orElse(null);
		
		if(senderAccount==null){
			throw new NoRecordFoundException("sender account number no found");
		}
		if(receiverAccount==null) {
			throw new NoRecordFoundException("recevier account number no found");
		}
		if(senderAccount==receiverAccount) {
			throw new NoRecordFoundException("both Account numbers are same");
		}
		if(senderAccount.getBalance()<amount) {
			throw new NoRecordFoundException("Insufficient Balance");
		}
		
	
			senderAccount.setBalance(senderAccount.getBalance()-amount);
			receiverAccount.setBalance(receiverAccount.getBalance()+amount);
			Customer customer = new Customer();

			Customer sender=senderAccount.getCustomer();
			sender.setTotalBalance(sender.getTotalBalance()-amount);
			
			Customer receiver=receiverAccount.getCustomer();
			receiver.setTotalBalance(receiver.getTotalBalance()+amount);
			
			customerRepository.save(sender);
			customerRepository.save(receiver);
			
			
			
			accountRepository.save(senderAccount);
			accountRepository.save(receiverAccount);
			
		Transaction transaction=new Transaction();
		transaction.setAmount(amount);
		transaction.setSenderAccount(senderAccount);
		transaction.setReceiverAccount(receiverAccount);
		transaction.setTransactionType(TransactionType.Transfer);
	
	    Transaction save = transactionRepository.save(transaction);
	 
	    
		return  convertTransactiontoTransactionDto(save);
			
		
	}


	private TransactionResponseDto convertTransactiontoTransactionDto(Transaction save) {
		
		TransactionResponseDto transactionResponseDto=new TransactionResponseDto();
		transactionResponseDto.setAmount(save.getAmount());
		transactionResponseDto.setId(save.getId());
		transactionResponseDto.setSenderAccount(convertAccounttoAccountResponseDto(save.getSenderAccount()));
		transactionResponseDto.setReceiverAccount(convertAccounttoAccountResponseDto(save.getReceiverAccount()));
		transactionResponseDto.setTransactionDate(save.getTransactionDate());
		transactionResponseDto.setTransactionType(save.getTransactionType());
		
		return transactionResponseDto;
		
	}


	


	private List<TransactionResponseDto> convertTransactiontoTransactionDto(List<Transaction> all) {
		
		List<TransactionResponseDto> transactionResponseDto=new ArrayList<>();
		for(Transaction t:all) {
			transactionResponseDto.add(convertTransactiontoTransactionDto(t));
			
		}
		return transactionResponseDto;
	}


	@Override
	public List<TransactionResponseDto> viewAllTransaction() {
		
		List<TransactionResponseDto> findAll=convertTransactiontoTransactionDto(transactionRepository.findAll());
		
		
		return findAll;
	}


	@Override
	public List<TransactionResponseDto> viewPassbook(long accountNo) {
		
		Account account= accountRepository.findById(accountNo).orElse(null);
		
		
		List<TransactionResponseDto> transactionResponseDto= covertPassbooktopassbookDto(transactionRepository.viewPassbook(account),accountNo);
		return transactionResponseDto;
		
		
		
		
		
	}


	private List<TransactionResponseDto> covertPassbooktopassbookDto(List<Transaction> viewPassbook,long accountNo) {
		List<TransactionResponseDto> transactionResponseDtos=new ArrayList<>();
		for(Transaction t :viewPassbook) {
			transactionResponseDtos.add(covertPassbooktopassbookDto(t,accountNo));
		}
		return transactionResponseDtos;
	}


	private TransactionResponseDto covertPassbooktopassbookDto(Transaction t,long accountNo) {
		 TransactionResponseDto transactionDto=new TransactionResponseDto();
		 
		 if((t.getSenderAccount().getAccountNumber())==accountNo) {
			 transactionDto.setTransactionType(TransactionType.Debit);
			 
		 }
		 else {
			 transactionDto.setTransactionType(TransactionType.Credit);
		 }
		 
		 transactionDto.setAmount(t.getAmount());
		 transactionDto.setId(t.getId());
		 transactionDto.setReceiverAccount(convertAccounttoAccountResponseDto(t.getReceiverAccount()));
		 transactionDto.setSenderAccount(convertAccounttoAccountResponseDto(t.getSenderAccount()));
		 transactionDto.setTransactionDate(t.getTransactionDate());
		return transactionDto;
	}


	@Override
	public List<TransactionResponseDto> searchByDate(LocalDateTime fromDate, LocalDateTime toDate) {
		
		return convertTransactiontoTransactionDto(transactionRepository.findByTransactionDateBetween(fromDate,toDate));
	}





	
}
