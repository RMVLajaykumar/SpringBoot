package com.monocept.app.entity;

public enum TransactionType {
	Debit, Credit, Transfer
}