package com.monocept.app.dto;



import lombok.Data;

@Data
public class ProfileResponseDto {
	private String firstName;
	private String lastName;
	private String username;
	private String password;
	
}
